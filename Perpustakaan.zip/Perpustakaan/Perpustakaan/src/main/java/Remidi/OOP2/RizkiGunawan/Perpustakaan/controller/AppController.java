package Remidi.OOP2.RizkiGunawan.Perpustakaan.controller;

import Remidi.OOP2.RizkiGunawan.Perpustakaan.entity.Databuku;
import Remidi.OOP2.RizkiGunawan.Perpustakaan.repo.BukuRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AppController {
    @Autowired
    private BukuRepo psRepo;

    @RequestMapping("/home")
    public void index() {
    }

    @RequestMapping("/data-buku")
    public void getDatasapi(Model model) {
        model.addAttribute("databuku", psRepo.findAll());
    }

    @RequestMapping("/jenis")
    public void getJenis(Model model) {
        model.addAttribute("jenis", psRepo.findAll());
    }


    @RequestMapping(value = "/tambah-data", method = RequestMethod.GET)
    public void getTambahData(@ModelAttribute("ps") Databuku ps, BindingResult binding) {
    }

    @RequestMapping(value = "/tambah-data", method = RequestMethod.POST)
    public String saveTambahData(@ModelAttribute("ps") Databuku ps, BindingResult binding) {
        System.out.println(ps.getClass());
        psRepo.save(ps);
        return "redirect:/data-buku";
    }
    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    public void getEdit(@RequestParam(name = "id", required = false) String id,
                        @ModelAttribute("ps") Databuku ps, BindingResult binding){
    }

    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public String saveEdit(@ModelAttribute("ps") Databuku ps, BindingResult binding){
        psRepo.save(ps);
        return "redirect:/data-buku";
    }

    @RequestMapping("/hapus")
    public String hapusdata(@RequestParam(name = "id", required = true) Databuku id) {
        psRepo.delete(id);
        return "redirect:/data-buku";
    }

}
