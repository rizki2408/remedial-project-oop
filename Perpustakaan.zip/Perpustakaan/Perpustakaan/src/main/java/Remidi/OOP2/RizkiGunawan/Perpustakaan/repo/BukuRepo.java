package Remidi.OOP2.RizkiGunawan.Perpustakaan.repo;

import Remidi.OOP2.RizkiGunawan.Perpustakaan.entity.Databuku;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BukuRepo extends JpaRepository<Databuku, Integer> {
}