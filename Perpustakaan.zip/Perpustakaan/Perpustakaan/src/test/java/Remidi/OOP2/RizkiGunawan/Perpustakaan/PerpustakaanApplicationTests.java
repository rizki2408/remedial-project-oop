package Remidi.OOP2.RizkiGunawan.Perpustakaan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerpustakaanApplicationTests {

	@Test
	void contextLoads() {
	}

}
